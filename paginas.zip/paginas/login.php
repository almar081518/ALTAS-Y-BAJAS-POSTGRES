
<?php
    //se declaran variables con $ para crear la conexion con la BD
    



    $conn = pg_connect("host='localhost' dbname=test port=5432 user=admin password=admin123  " )
     or die("No hay conexxion:".pg_last_error());


     
   
$nombre=$_POST["txtusuario"]; // toma las variables de el form toma lo avalores 
$pass=$_POST["txtpassword"];
$query = pg_query($conn,"SELECT * FROM login WHERE usuario='".$nombre."' and password = '".$pass."'");//login es la tabla que se ocupara para los ususarios
$nr=pg_num_rows($query);// devuelve el numero de registros dados fila

if($nr==1)
{
    header("Location:inicio.html"); //se direcciona a la pagina inicio.html


}
else if($nr==0)
{
    header("Location:login.html");//direcciona a la pagina del login
}
?>
</html>