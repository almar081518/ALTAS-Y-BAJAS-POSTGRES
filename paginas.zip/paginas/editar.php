<?php


if(isset($_GET['editar'])){
	$editar = $_GET['editar'];

	$query = "SELECT * FROM prod WHERE id = $editar";

   
	$ejecutar = pg_query($con, $query);

	$fila = pg_fetch_array($ejecutar);//CREANSO UN ARRAY CON INDICES ASOCIATIVOS

	    if(isset($fila['nombrep'])){
        $nombreP = $fila['nombrep'];
    }
   if(isset($fila['precio'])){
	$precio = $fila['precio'];
    }
    if(isset($fila['categoria'])){// COMPARA SI ALGUN VALOR RECIBE INSERCION EN CASO CONTRARIO NULL
	$categoria = $fila['categoria'];
    }

}
?>


<br />
<form method="POST" action="">
	<LABEL> PRODUCTO <BR></LABEL>
<input type="text" name="nombrep" value="<?php echo $nombreP; ?>"><br /><BR>	
<LABEL> PRECIO <BR></LABEL>
<input type="real" name="precio" value="<?php echo $precio; ?>"><br /><BR>
<LABEL> CATEGORIA  <BR></LABEL>
<input type="TEXT" name="categoria" value="<?php echo $categoria; ?>"><br />
</br>
</br>
<input type="submiT" name="actualizar" value="ACTUALIZAR DATOS">
</form>

<?php
if (isset($_POST['actualizar'])){
$actualizar_nombreP = $_POST['nombrep'];
$actualizar_precio = $_POST['precio'];
$actualizar_categoria = $_POST['categoria'];

$query= "UPDATE prod SET nombrep='$actualizar_nombreP', precio='$actualizar_precio', categoria='$actualizar_categoria' WHERE id='$editar'";
 pg_query($con, $query);

if ($ejecutar){
	echo "<script>alert('Datos Actualizados!')</script>";
	echo "<script>windoows.open('AYB.php','_self')</script>";
    
}
}
?>
