<!DOCTYPE html>
<meta charset="UTF-8">

<?php
// aquii se crea la conexion de la BD
$con= pg_connect("host='localhost' dbname=test port=5432 user=admin password=admin123  " )
or die("No hay conexxion:".pg_last_error());


?>
<html>
<head>
	<title>inicio</title>
	</HEAD><H1><P ALIGN="CENTER"><FONT SIZE="7" COLOR="WHITE" FACE="Candyshop"> </H1><B><B></FONT> <B><B>
	<meta charset="utf-8">
</head>
<body background="FINAL_Mesa de trabajo 1.jpg"></body>


<H1> INSERTAR DATOS</H1>
<br><br><br><br>
 <form method="POST" action="AYB.php">
 <FONT SIZE="5" COLOR="black" FACE="Candypop!"> <label>Nombre del producto:<br></label></FONT>
	 <input type="text" name="nombrep" placeholder = "Escriba el  producto"><br />
	 <FONT SIZE="5" COLOR="black" FACE="Candypop!"> <label>Precio:<br> </label></FONT>
	 <input type="real" name="precio" placeholder = "Escriba el precio"><br />
	 <FONT SIZE="5" COLOR="black" FACE="Candypop!"> <label>Categoria:<br></label></FONT>
	 <input type="texto" name="categoria" placeholder = "Escriba la categoria"><br /><br>
	 <FONT SIZE="5" COLOR="black" FACE="Candypop!"> <input type="submit" name="insert" value = "INSERTAR DATOS"></FONT>

 </form>

<?php
	if(isset($_POST["insert"])){
		$nombreP = $_POST["nombrep"];
		$precio = $_POST["precio"];
		$categoria = $_POST["categoria"];

		$insertar = "INSERT INTO prod (nombrep,precio,categoria) VALUES ('$nombreP', '$precio', '$categoria')";
		$ejecutar = pg_query($con, $insertar);

		if ($ejecutar){
			echo "<h3>Insertado Correctamente</h3>";
		}
	}
?>






<center><table width="500" border="2" style="background-color: WHITE; ">
	<tr>
		<th>Id producto</th>
		<th>nombre de producto</th>
		<th>precio</th>
		<th>categoria</th>
		<th>Editar</th>
		<th>Borrar</th>
	</tr></center>
<?php
$consulta = "SELECT * FROM prod";
$ejecutar = pg_query($con, $consulta);
$i = 0;
while ( $fila = pg_fetch_array($ejecutar)) {
	$id = $fila['id'];
	$nombreP = $fila['nombrep'];
	$precio = $fila['precio'];
	$categoria = $fila['categoria'];

	$i++;

?>

<tr align="center">
<td><?php echo $id; ?></td>
<td><?php echo $nombreP; ?></td>
<td><?php echo $precio; ?></td>
<td><?php echo $categoria; ?></td>
<td><a href="AYB.php?editar=<?php echo $id; ?>">Editar</a></td>
<td><a href="AYB.php?borrar=<?php echo $id; ?>">Borrar</a></td>
</tr>
<?php } ?>
</table>

<?php
if(isset($_GET['editar'])){
	include("editar.php");// CREANDO EN ENLSCE EDITAR MANADA A EDITAR <.PJP
}
?>

<?php
if(isset($_GET['borrar'])){
	$borrar_id = $_GET['borrar'];
	$borrar = "DELETE FROM prod WHERE id = '$borrar_id'";//LINK DE BORRAR
	$ejecutar = pg_query($con, $borrar);

	if ($ejecutar){
		echo "<script>alert('El prodcuto ha sido borrado!')</script>";
		echo "<script>windoows.open('AYB.php','_self')</script>";
        
	}

}
?>
<br><br>
<center>
<a href="AYB.php"><input type="submit" value="Actualizar" /></a>

<a href="inicio.html"><input type="submit" value="regresar a inicio" /></a>
</center>

</body>
</html>
