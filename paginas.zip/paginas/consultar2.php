<html>
    <head> 
        <tiltle></tilte>
        <meta charset="utf-8">
        
    </head>

    <body>
        <h1>Resultados de la consulta </h1>

        <?php 
$con= pg_connect("host='localhost' dbname=test port=5432 user=admin password=admin123  " )
or die("No hay conexxion:".pg_last_error());

           
           
                $registros = pg_query($con, "SELECT  id,nombrep, precio, categoria FROM prod
                WHERE nombrep = '$_REQUEST[nombrep]';");

                    if($reg = pg_fetch_array($registros)){
                        echo "ID PRODUCTO : " . $reg['id'] . "<br>";
                        echo "NOMBRE :" . $reg['nombrep'] . "<br>";
                        echo "PRECIO :" . $reg['precio'] . "<br>";
                        echo "CATEGORIA:" . $reg['categoria'];
            
                    } else{
                        echo "No existe producto";
                    }

            pg_close($con);

        ?>

        <br><br>
        <form action = "consultas.php" method = "POST" name = "agregar" class ="agregar">
            <button class = "submit" type = "submit">Regresar</button>
        </form>



    </body>
</html>