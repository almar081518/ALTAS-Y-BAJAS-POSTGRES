<!DOCTYPE html>
<meta charset="UTF-8">


<html>
    <head>
        <meta charset = "utf-8">
       
    </head>

    <body background="wwww-03.jpg"></body>
        <div id = "contenedor">
            <header id = "encabezado">

                    <header>
                        <hgroup>
                           
                            <br>
                            <br>
                        </hgroup>
                    </header>

                 
<BR><BR><BR><BR>
                    <CENTER>
                    <form action = "conexion.php" method = "POST" name = "agregar" class="agregar">
                      
                      <H1>  Nombre:</H1>
                        <input type = "text" name = "nombrep"> <br><br>
                
                        <!--<input type = "submit" value = "Guardar registro"><br><br>-->
                        <button class = "submit" type = "submit">Consultar producto</button><br><br>



                        
                    </form>

                    <a href="inicio.html"><input type="submit" value="regresar a inicio" /></a>
                    
                    <br>

                    </CENTER>

                </article>

              
                
                </aside>

            </section>


        </div>
    </body>
</html>